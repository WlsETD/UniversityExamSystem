import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int s = sc.nextInt();
        System.out.print(s >= 60 ? "Pass" : "Fail");
    }
}
