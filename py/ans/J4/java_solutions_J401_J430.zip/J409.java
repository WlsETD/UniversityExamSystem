import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        switch (m){
            case 1:
                System.out.print("Jan");
                break;
            default:
                System.out.print("Others");
        }
    }
}
