import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        System.out.print(t >= 30 ? "Hot" : "Cold");
    }
}
